//alert函数扩展
window.alert = function(){
	var title='温馨提示';
	var msg='';
	if(arguments && arguments.length>0){
		msg = arguments[0];
	}
	$.messager.alert(title,msg);
};

$(function(){
	//修改form属性autocomplete="off"
	$(document).find('form').attr('autocomplete','off');
	
	//处理日期图标遮挡的问题
	$('.row-fluid td').children('input.Wdate').each(function(){
		if($.trim($(this).val()) === '') {
			$(this).addClass('date-choose');
		}else {
			$(this).removeClass('date-choose');
		}
	});
	$('.row-fluid td').children('input.Wdate').on('focus blur',function(){
		if($.trim($(this).val()) === '') {
			$(this).addClass('date-choose');
		}else {
			$(this).removeClass('date-choose');
		}
	});
})

//复制案件编号
function copyAjbh(target){
	var rawAjbh = $(target).attr("rel");
	var oInput = document.createElement('input');
	oInput.value = rawAjbh;
	document.body.appendChild(oInput);
	oInput.select(); // 选择对象
	document.execCommand("Copy"); // 执行浏览器复制命令
	oInput.className = 'oInput';
	oInput.style.display='none';
	window.event? window.event.cancelBubble = true : e.stopPropagation();
	//$.messager.alert("系统提示","复制成功","info");
}